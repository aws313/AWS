"use client"

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import { TextReveal, ImageReveal } from './page-transition'
import { Award, Briefcase, MapPin, Calendar } from 'lucide-react'

const stats = [
  { label: 'Years Experience', value: '10+', icon: Calendar },
  { label: 'Projects Completed', value: '150+', icon: Briefcase },
  { label: 'Awards Won', value: '25+', icon: Award },
  { label: 'Countries', value: '12', icon: MapPin },
]

const skills = [
  'Brand Identity', 'Video Editing', 'Motion Graphics', 
  'Typography', 'Color Grading', 'Visual Effects'
]

export function AboutSection() {
  const containerRef = useRef<HTMLElement>(null)
  const isInView = useInView(containerRef, { once: true, margin: "-100px" })

  return (
    <section 
      ref={containerRef}
      id="about" 
      className="min-h-screen flex items-center py-20 px-4"
    >
      <div className="max-w-7xl mx-auto w-full">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Image */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="relative"
          >
            <ImageReveal delay={0.2}>
              <div className="relative aspect-[4/5] rounded-2xl overflow-hidden">
                <div 
                  className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20"
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%2300d4ff' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                  }}
                />
                {/* Placeholder for designer image */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div
                    className="w-48 h-48 rounded-full bg-gradient-to-br from-primary to-accent"
                    animate={{
                      boxShadow: [
                        '0 0 40px rgba(0, 212, 255, 0.4)',
                        '0 0 80px rgba(255, 0, 128, 0.4)',
                        '0 0 40px rgba(0, 212, 255, 0.4)',
                      ]
                    }}
                    transition={{ duration: 3, repeat: Infinity }}
                  />
                </div>
                {/* Decorative elements */}
                <motion.div
                  className="absolute top-8 right-8 w-20 h-20 border border-primary/50 rounded-lg"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                />
                <motion.div
                  className="absolute bottom-8 left-8 w-16 h-16 border border-accent/50 rounded-full"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 3, repeat: Infinity }}
                />
              </div>
            </ImageReveal>
            
            {/* Floating badge */}
            <motion.div
              className="absolute -bottom-6 -right-6 glass-card px-6 py-4 rounded-xl"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: 0.6, duration: 0.5 }}
            >
              <p className="text-sm text-muted-foreground">Available for</p>
              <p className="text-lg font-semibold text-primary">Freelance Work</p>
            </motion.div>
          </motion.div>

          {/* Right - Content */}
          <div className="space-y-8">
            <div>
              <motion.p
                className="text-primary text-sm tracking-[0.3em] uppercase mb-4"
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6 }}
              >
                About Me
              </motion.p>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
                {isInView && (
                  <TextReveal 
                    text="Crafting Digital Experiences" 
                    className="text-glow-cyan"
                  />
                )}
              </h2>
              <motion.p
                className="text-muted-foreground text-lg leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.4, duration: 0.6 }}
              >
                Welcome to Designer OS. As a Senior Graphic Design and Video Editor with over a decade 
                of experience, I transform complex ideas into compelling visual narratives. My work spans 
                brand identity, motion graphics, video production, and immersive experiences that push the 
                boundaries of what&apos;s possible in design.
              </motion.p>
            </div>

            {/* Stats */}
            <motion.div
              className="grid grid-cols-2 md:grid-cols-4 gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.5, duration: 0.6 }}
            >
              {stats.map((stat, i) => (
                <motion.div
                  key={stat.label}
                  className="glass-card p-4 rounded-xl text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 0.6 + i * 0.1, duration: 0.5 }}
                  whileHover={{ 
                    scale: 1.05,
                    boxShadow: '0 0 30px rgba(0, 212, 255, 0.3)'
                  }}
                >
                  <stat.icon className="w-5 h-5 text-primary mx-auto mb-2" />
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </motion.div>
              ))}
            </motion.div>

            {/* Skills */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.8, duration: 0.6 }}
            >
              <p className="text-sm text-muted-foreground mb-4">Expertise</p>
              <div className="flex flex-wrap gap-3">
                {skills.map((skill, i) => (
                  <motion.span
                    key={skill}
                    className="px-4 py-2 rounded-full text-sm border border-primary/30 text-primary hover:bg-primary/10 transition-colors cursor-default"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={isInView ? { opacity: 1, scale: 1 } : {}}
                    transition={{ delay: 0.9 + i * 0.05, duration: 0.3 }}
                    whileHover={{ scale: 1.05 }}
                  >
                    {skill}
                  </motion.span>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}
