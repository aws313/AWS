"use client"

import { useRef, useState } from 'react'
import { motion, useInView } from 'framer-motion'
import { Send, Mail, MapPin, ArrowUpRight, Linkedin, Github, Twitter } from 'lucide-react'

const socialLinks = [
  { name: "LinkedIn", icon: Linkedin, href: "#", color: "oklch(0.75 0.18 195)" },
  { name: "GitHub", icon: Github, href: "#", color: "oklch(0.65 0.25 330)" },
  { name: "Twitter", icon: Twitter, href: "#", color: "oklch(0.7 0.2 145)" },
]

export function ContactSection() {
  const ref = useRef<HTMLElement>(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })
  const [isHovered, setIsHovered] = useState(false)
  const [formData, setFormData] = useState({ name: '', email: '', message: '' })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log(formData)
  }

  return (
    <section ref={ref} className="relative py-32 px-4" id="contact">
      {/* Background gradient */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div 
          className="absolute w-[800px] h-[800px] rounded-full blur-[150px] opacity-20"
          style={{
            background: 'radial-gradient(circle, oklch(0.75 0.18 195) 0%, transparent 70%)',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
          }}
        />
      </div>

      {/* Section header */}
      <motion.div
        className="text-center mb-20 relative z-10"
        initial={{ opacity: 0, y: 30 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.8 }}
      >
        <span className="text-accent font-mono text-sm tracking-[0.3em] uppercase">Connect</span>
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mt-4 text-glow-cyan">
          {"Let's Create Together"}
        </h2>
        <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
          Have a project in mind? I&apos;d love to hear about it.
        </p>
      </motion.div>

      <div className="max-w-5xl mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Contact info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-4">Get in Touch</h3>
              <p className="text-muted-foreground leading-relaxed">
                I&apos;m always interested in hearing about new projects, creative ideas, 
                or opportunities to be part of your visions.
              </p>
            </div>

            <div className="space-y-4">
              <motion.a
                href="mailto:hello@alexchen.design"
                className="flex items-center gap-4 p-4 rounded-xl glass-card group"
                whileHover={{ x: 10, boxShadow: '0 0 30px oklch(0.75 0.18 195 / 0.2)' }}
              >
                <div className="w-12 h-12 rounded-lg flex items-center justify-center bg-primary/20">
                  <Mail className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Email</span>
                  <p className="text-foreground group-hover:text-primary transition-colors">
                    hello@alexchen.design
                  </p>
                </div>
                <ArrowUpRight className="w-5 h-5 text-muted-foreground ml-auto group-hover:text-primary transition-colors" />
              </motion.a>

              <motion.div
                className="flex items-center gap-4 p-4 rounded-xl glass-card"
                whileHover={{ x: 10 }}
              >
                <div className="w-12 h-12 rounded-lg flex items-center justify-center bg-accent/20">
                  <MapPin className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Location</span>
                  <p className="text-foreground">San Francisco, CA</p>
                </div>
              </motion.div>
            </div>

            {/* Social links */}
            <div>
              <span className="text-sm text-muted-foreground block mb-4">Follow me</span>
              <div className="flex gap-4">
                {socialLinks.map((social, i) => {
                  const Icon = social.icon
                  return (
                    <motion.a
                      key={social.name}
                      href={social.href}
                      className="w-12 h-12 rounded-lg flex items-center justify-center glass-card"
                      initial={{ opacity: 0, y: 20 }}
                      animate={isInView ? { opacity: 1, y: 0 } : {}}
                      transition={{ delay: 0.4 + i * 0.1 }}
                      whileHover={{ 
                        scale: 1.1,
                        boxShadow: `0 0 25px ${social.color}40`
                      }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Icon className="w-5 h-5 text-muted-foreground hover:text-foreground transition-colors" />
                    </motion.a>
                  )
                })}
              </div>
            </div>
          </motion.div>

          {/* Contact form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="text-sm text-muted-foreground block mb-2">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all text-foreground placeholder:text-muted-foreground"
                  placeholder="Your name"
                  required
                />
              </div>
              
              <div>
                <label className="text-sm text-muted-foreground block mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all text-foreground placeholder:text-muted-foreground"
                  placeholder="your@email.com"
                  required
                />
              </div>
              
              <div>
                <label className="text-sm text-muted-foreground block mb-2">Message</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg bg-input border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all text-foreground placeholder:text-muted-foreground resize-none h-32"
                  placeholder="Tell me about your project..."
                  required
                />
              </div>

              {/* Glowing submit button */}
              <motion.button
                type="submit"
                className="relative w-full py-4 rounded-lg overflow-hidden group"
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {/* Background gradient */}
                <motion.span
                  className="absolute inset-0"
                  style={{
                    background: 'linear-gradient(135deg, oklch(0.75 0.18 195) 0%, oklch(0.65 0.25 330) 100%)'
                  }}
                  animate={{
                    opacity: isHovered ? 1 : 0.9
                  }}
                />
                
                {/* Animated glow */}
                <motion.span
                  className="absolute inset-0"
                  animate={{
                    boxShadow: isHovered 
                      ? '0 0 40px oklch(0.75 0.18 195 / 0.6), 0 0 80px oklch(0.65 0.25 330 / 0.4), inset 0 0 40px oklch(0.75 0.18 195 / 0.2)'
                      : '0 0 20px oklch(0.75 0.18 195 / 0.3)'
                  }}
                  transition={{ duration: 0.3 }}
                />

                {/* Shine effect */}
                <motion.span
                  className="absolute inset-0 opacity-0 group-hover:opacity-100"
                  style={{
                    background: 'linear-gradient(90deg, transparent 0%, oklch(1 0 0 / 0.2) 50%, transparent 100%)',
                  }}
                  animate={isHovered ? {
                    x: ['-100%', '200%']
                  } : {}}
                  transition={{
                    duration: 0.8,
                    ease: "easeInOut"
                  }}
                />

                {/* Button content */}
                <span className="relative z-10 flex items-center justify-center gap-2 text-primary-foreground font-semibold tracking-wider uppercase text-sm">
                  <span>Send Message</span>
                  <motion.span
                    animate={isHovered ? { x: 5, y: -5 } : { x: 0, y: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Send className="w-4 h-4" />
                  </motion.span>
                </span>
              </motion.button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
