"use client"

import { useState, useRef } from 'react'
import { motion, useInView, AnimatePresence } from 'framer-motion'
import { Play, Pause, Volume2, VolumeX, Maximize2, Clock, Eye } from 'lucide-react'

const videos = [
  { 
    id: 1, 
    title: 'Brand Motion Reel 2024', 
    duration: '2:34', 
    views: '12.4K',
    category: 'Motion Graphics',
    color: '#00d4ff',
    featured: true 
  },
  { 
    id: 2, 
    title: 'Logo Animation Collection', 
    duration: '1:45', 
    views: '8.7K',
    category: 'Logo Animation',
    color: '#ff0080',
    featured: false 
  },
  { 
    id: 3, 
    title: 'UI Interaction Showcase', 
    duration: '3:12', 
    views: '15.2K',
    category: 'UI/UX',
    color: '#8a2be2',
    featured: false 
  },
  { 
    id: 4, 
    title: '3D Product Visualization', 
    duration: '2:08', 
    views: '9.3K',
    category: '3D Design',
    color: '#00d4ff',
    featured: false 
  },
  { 
    id: 5, 
    title: 'Typography in Motion', 
    duration: '1:56', 
    views: '11.1K',
    category: 'Typography',
    color: '#ff0080',
    featured: false 
  },
  { 
    id: 6, 
    title: 'Abstract Visual Journey', 
    duration: '4:21', 
    views: '18.9K',
    category: 'Experimental',
    color: '#8a2be2',
    featured: false 
  },
]

export function VideosSection() {
  const [hoveredId, setHoveredId] = useState<number | null>(null)
  const [playingId, setPlayingId] = useState<number | null>(null)
  const [selectedVideo, setSelectedVideo] = useState<typeof videos[0] | null>(null)
  const containerRef = useRef<HTMLElement>(null)
  const isInView = useInView(containerRef, { once: true, margin: "-100px" })

  const featuredVideo = videos.find(v => v.featured)
  const otherVideos = videos.filter(v => !v.featured)

  return (
    <section 
      ref={containerRef}
      id="videos" 
      className="min-h-screen py-20 px-4"
    >
      {/* Section title */}
      <motion.div
        className="text-center mb-16"
        initial={{ opacity: 0, y: 30 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.8 }}
      >
        <p className="text-[oklch(0.6_0.2_280)] text-sm tracking-[0.3em] uppercase mb-4">Showcase</p>
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold">
          <span className="text-glow-cyan">Motion</span>{' '}
          <span className="text-glow-magenta">Works</span>
        </h2>
      </motion.div>

      <div className="max-w-7xl mx-auto">
        {/* Featured video */}
        {featuredVideo && (
          <motion.div
            className="mb-12"
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <motion.div
              className="relative aspect-video rounded-2xl overflow-hidden cursor-pointer"
              style={{
                background: `linear-gradient(135deg, ${featuredVideo.color}20 0%, ${featuredVideo.color}05 100%)`,
                border: `2px solid ${featuredVideo.color}40`,
              }}
              whileHover={{ 
                boxShadow: `0 0 60px ${featuredVideo.color}40, 0 0 120px ${featuredVideo.color}20`,
              }}
              onClick={() => setSelectedVideo(featuredVideo)}
            >
              {/* Video placeholder with animated elements */}
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  className="w-40 h-40 rounded-full relative"
                  style={{
                    background: `radial-gradient(circle, ${featuredVideo.color}40 0%, transparent 70%)`,
                  }}
                >
                  {/* Orbiting rings */}
                  <motion.div
                    className="absolute inset-0 border-2 rounded-full"
                    style={{ borderColor: `${featuredVideo.color}60` }}
                    animate={{ rotate: 360 }}
                    transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
                  />
                  <motion.div
                    className="absolute inset-4 border rounded-full"
                    style={{ borderColor: `${featuredVideo.color}40` }}
                    animate={{ rotate: -360 }}
                    transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
                  />
                  
                  {/* Play button */}
                  <motion.div
                    className="absolute inset-0 flex items-center justify-center"
                    whileHover={{ scale: 1.1 }}
                  >
                    <div 
                      className="w-20 h-20 rounded-full flex items-center justify-center"
                      style={{
                        background: featuredVideo.color,
                        boxShadow: `0 0 40px ${featuredVideo.color}80`,
                      }}
                    >
                      <Play className="w-8 h-8 text-background ml-1" fill="currentColor" />
                    </div>
                  </motion.div>
                </motion.div>
              </div>

              {/* Animated wave pattern */}
              <svg className="absolute bottom-0 left-0 right-0 h-32 opacity-30" preserveAspectRatio="none">
                <motion.path
                  d="M0,100 Q200,50 400,100 T800,100 T1200,100 T1600,100 V200 H0 Z"
                  fill={featuredVideo.color}
                  initial={{ d: "M0,100 Q200,50 400,100 T800,100 T1200,100 T1600,100 V200 H0 Z" }}
                  animate={{ 
                    d: [
                      "M0,100 Q200,50 400,100 T800,100 T1200,100 T1600,100 V200 H0 Z",
                      "M0,100 Q200,150 400,100 T800,100 T1200,100 T1600,100 V200 H0 Z",
                      "M0,100 Q200,50 400,100 T800,100 T1200,100 T1600,100 V200 H0 Z",
                    ]
                  }}
                  transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                />
              </svg>

              {/* Info overlay */}
              <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-background/90 to-transparent">
                <div className="flex items-end justify-between">
                  <div>
                    <span 
                      className="text-xs tracking-wider uppercase px-3 py-1 rounded-full mb-2 inline-block"
                      style={{ 
                        background: `${featuredVideo.color}20`,
                        color: featuredVideo.color,
                        border: `1px solid ${featuredVideo.color}40`
                      }}
                    >
                      Featured
                    </span>
                    <h3 className="text-2xl md:text-3xl font-bold text-foreground">{featuredVideo.title}</h3>
                    <p className="text-muted-foreground">{featuredVideo.category}</p>
                  </div>
                  <div className="flex gap-4 text-muted-foreground text-sm">
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {featuredVideo.duration}
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {featuredVideo.views}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Video grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {otherVideos.map((video, index) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
              onHoverStart={() => setHoveredId(video.id)}
              onHoverEnd={() => setHoveredId(null)}
              onClick={() => setSelectedVideo(video)}
              className="cursor-pointer"
            >
              <motion.div
                className="aspect-video rounded-xl overflow-hidden relative"
                style={{
                  background: `linear-gradient(135deg, ${video.color}20 0%, ${video.color}05 100%)`,
                  border: `1px solid ${video.color}30`,
                }}
                animate={{
                  boxShadow: hoveredId === video.id 
                    ? `0 0 40px ${video.color}40`
                    : `0 0 20px ${video.color}10`,
                  scale: hoveredId === video.id ? 1.02 : 1,
                }}
                transition={{ duration: 0.3 }}
              >
                {/* Video placeholder */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div
                    className="w-16 h-16 rounded-full flex items-center justify-center"
                    style={{
                      background: `${video.color}30`,
                      border: `2px solid ${video.color}60`,
                    }}
                    animate={{
                      scale: hoveredId === video.id ? [1, 1.1, 1] : 1,
                    }}
                    transition={{ duration: 0.5, repeat: hoveredId === video.id ? Infinity : 0 }}
                  >
                    <Play 
                      className="w-6 h-6 ml-0.5" 
                      style={{ color: video.color }} 
                      fill="currentColor"
                    />
                  </motion.div>
                </div>

                {/* Animated border on hover */}
                <AnimatePresence>
                  {hoveredId === video.id && (
                    <motion.div
                      className="absolute inset-0 pointer-events-none"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                    >
                      <svg className="w-full h-full">
                        <rect
                          x="1"
                          y="1"
                          width="calc(100% - 2px)"
                          height="calc(100% - 2px)"
                          rx="12"
                          fill="none"
                          stroke={video.color}
                          strokeWidth="2"
                          strokeDasharray="10 5"
                          className="animate-[dash_2s_linear_infinite]"
                        />
                      </svg>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Duration badge */}
                <div 
                  className="absolute bottom-3 right-3 px-2 py-1 rounded text-xs font-medium"
                  style={{ 
                    background: 'rgba(0,0,0,0.7)',
                    color: video.color 
                  }}
                >
                  {video.duration}
                </div>
              </motion.div>

              {/* Info */}
              <div className="mt-3">
                <h4 className="font-semibold text-foreground">{video.title}</h4>
                <div className="flex items-center justify-between text-sm text-muted-foreground mt-1">
                  <span>{video.category}</span>
                  <span className="flex items-center gap-1">
                    <Eye className="w-3 h-3" />
                    {video.views}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Video modal */}
      <AnimatePresence>
        {selectedVideo && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-background/95 backdrop-blur-lg p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedVideo(null)}
          >
            <motion.div
              className="max-w-4xl w-full rounded-2xl overflow-hidden"
              style={{
                background: `linear-gradient(135deg, ${selectedVideo.color}15 0%, ${selectedVideo.color}05 100%)`,
                border: `2px solid ${selectedVideo.color}50`,
                boxShadow: `0 0 100px ${selectedVideo.color}30`,
              }}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Video player area */}
              <div className="aspect-video relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div
                    className="w-32 h-32 rounded-full"
                    style={{
                      background: `radial-gradient(circle, ${selectedVideo.color}60 0%, transparent 70%)`,
                    }}
                    animate={{
                      scale: [1, 1.2, 1],
                      opacity: [0.5, 0.8, 0.5],
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                </div>

                {/* Controls overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-background to-transparent">
                  <div className="flex items-center gap-4">
                    <motion.button
                      className="w-10 h-10 rounded-full flex items-center justify-center"
                      style={{ background: selectedVideo.color }}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setPlayingId(playingId === selectedVideo.id ? null : selectedVideo.id)}
                    >
                      {playingId === selectedVideo.id ? (
                        <Pause className="w-5 h-5 text-background" fill="currentColor" />
                      ) : (
                        <Play className="w-5 h-5 text-background ml-0.5" fill="currentColor" />
                      )}
                    </motion.button>
                    
                    {/* Progress bar */}
                    <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ background: selectedVideo.color }}
                        initial={{ width: '0%' }}
                        animate={{ width: playingId === selectedVideo.id ? '100%' : '0%' }}
                        transition={{ duration: 10, ease: 'linear' }}
                      />
                    </div>

                    <span className="text-sm text-muted-foreground">{selectedVideo.duration}</span>
                    
                    <motion.button
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground"
                      whileHover={{ scale: 1.1 }}
                    >
                      <Volume2 className="w-4 h-4" />
                    </motion.button>
                    
                    <motion.button
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground"
                      whileHover={{ scale: 1.1 }}
                    >
                      <Maximize2 className="w-4 h-4" />
                    </motion.button>
                  </div>
                </div>
              </div>

              {/* Info */}
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <span 
                      className="text-xs tracking-wider uppercase px-3 py-1 rounded-full mb-2 inline-block"
                      style={{ 
                        background: `${selectedVideo.color}20`,
                        color: selectedVideo.color,
                      }}
                    >
                      {selectedVideo.category}
                    </span>
                    <h3 className="text-2xl font-bold text-foreground">{selectedVideo.title}</h3>
                    <p className="text-muted-foreground mt-2">
                      A captivating exploration of motion and design, showcasing innovative techniques and creative storytelling.
                    </p>
                  </div>
                  <div className="text-right text-sm text-muted-foreground">
                    <p className="flex items-center gap-1 justify-end">
                      <Eye className="w-4 h-4" />
                      {selectedVideo.views} views
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <style jsx>{`
        @keyframes dash {
          to {
            stroke-dashoffset: -30;
          }
        }
      `}</style>
    </section>
  )
}
